package crud;

import java.util.Scanner;

import Agencia.Passagem;
import DAO.CompraDAO;
import DAO.PassagemDAO;
import DAO.UsuarioDAO;

public class PassagemCRUD {

	
	@SuppressWarnings("unused")
	public static void main(String[] args) {
	
		
		
		PassagemDAO passagemDAO = new PassagemDAO();
		UsuarioDAO usuarioDAO = new UsuarioDAO();
		CompraDAO compraDAO = new CompraDAO();

		Scanner s = new Scanner(System.in);
		int opcao = 0;
		int posicao = 0;
		
		int id_passagem = 0;
		String destino = "";
		String origem = "";
		double valor1 = 0;
		

		do {
			System.out.println("===  Passagens ===");
			System.out.println("1 - Comprar Passagens");
			System.out.println("2 - Consultar Passagens");
			System.out.println("3 - Atualizar Passagens");
			System.out.println("4 - Excluir Passagens");
			System.out.println("5 - Buscar por id");
			System.out.println("0 - Sair");
			opcao = s.nextInt();
			s.nextLine();

			switch (opcao) {
			case 1:
				// CREATE
				System.out.println("Digite a sua Origem: ");
				origem = s.nextLine();
				System.out.println("Digite o seu Destino: ");
				destino = s.nextLine();
				System.out.println("O valor da Passagem é: R$ X,XXX ");
				valor1 = s.nextDouble();
				s.nextLine();
				System.out.println("Este  é o CODIGO da sua Passagem ");
				id_passagem = s.nextInt();
				s.nextLine();
				
				
				PassagemCRUD.getPassagemById();
				CompraDAO.getCompraById(valor1);

				PassagemCRUD.save();

				System.out.println("\n***  Cadastrou  ***\n");

				break;
			case 2:
				// READ
				for (Agencia.Passagem l : PassagemDAO()) {
					System.out.println("Id: " + l.getID_Passagem() + " Destino: " + l.getDestino() 
					+ " Valor : "+ l.getValor());
				}

				PassagemCRUD.getPassagemById(id_passagem);
				CompraDAO.getCompraById(id_passagem);

				PassagemCRUD.save();
				System.out.println("consultou");
				break;
			case 3:
				// UPDATE
				System.out.println("Digite o id da sua passagem: ");
				posicao = s.nextInt();
				s.nextLine();
				System.out.println("Digite o destino ");
				destino = s.nextLine();
				System.out.println("Digite o preco da passagem: ");
				valor1 = s.nextDouble();
				
				
				PassagemDAO.getPassagemById(id_passagem);
				CompraDAO.getCompraById(id_passagem);

				PassagemDAO l2 = new PassagemDAO(id_passagem, destino, valor1);

				PassagemDAO.update(l2);

				System.out.println("atualizou" + PassagemDAO.getPassagem());
				break;
			case 4:
				// DELETE
				System.out.println("Digite o id da passagem: ");
				posicao = s.nextInt();

				PassagemDAO.deleteById(posicao);

				break;
			case 5:
				// buscar por id
				System.out.println("Digite o id da passagem: ");
				posicao = s.nextInt();

				PassagemCRUD l3 = PassagemDAO.getPassagemById(posicao);

				System.out.println("Id: " + l3.getId_Passagem() + " Destino: " + l3.getDestino() 
				+ " Valor: "+ l3.getValor());

				break;
			default:
				System.out.println(opcao != 0 ? "opcao invalida, digite novamente." : "");
				break;
			}

		} while (opcao != 0);

		System.out.println("Ate mais!");
		s.close();
	}


	private static void getPassagemById(int id_passagem) {
		return;
	}


	private static Passagem[] PassagemDAO() {
		return null;
	}


	public String getId_Passagem() {
		return this.getID_Passagem();
	}


	public PassagemCRUD() {
		return;
	}

	public static void save() {
		return;
	}

	public static void getPassagemById() {
		return;
	}

	public String getValor() {
		return this.getValor();
	}

	public String getDestino() {
		return this.getDestino();
	}

	public String getID_Passagem() {
		return this.getID_Passagem();
	}


	public String getID_Cliente() { 
		return this.getID_Cliente();
	}


	public String getIda() {
		return this.getIda();
	}


	public String getVolta() {
		return this.getVolta();
	}
}

