package crud;

import java.util.Arrays;
import Agencia.Passagem;
import Agencia.Passagens;
import Agencia.Permissoes;

import DAO.CompraDAO;
import DAO.PassagemDAO;
import DAO.UsuarioDAO;

public class PrincipalCRUD {
	
	public static void main(String[] args) {
		
		PassagemDAO passagemDAO = new PassagemDAO();
		UsuarioDAO usuarioDAO = new UsuarioDAO();
		CompraDAO compraDAO = new CompraDAO();
		
		Permissoes p1 = new Permissoes(1, "comum");
		Permissoes p2 = new Permissoes(2, "administrador");
		
		UsuarioDAO u1 = new UsuarioDAO(1, "Pedro", "pedro@email", "1234", p2);
		UsuarioDAO u2 = new UsuarioDAO(2, "Julia", "julia@email", "4321", p1);
		UsuarioDAO u3 = new UsuarioDAO(3, "Henrique", "henrique@email", "1245", p1);
		
		System.out.println(u1.mostrar());
		System.out.println(u2.mostrar());
		System.out.println(u3.mostrar());
			
		CompraDAO c1 = new CompraDAO(1, u3);
		
		PassagemDAO i1 = new PassagemDAO(1, 3, c1 );
		PassagemDAO i2 = new PassagemDAO(2, 1, c1);
		
		c1.getPassagens().add((Passagens) Arrays.asList(i1));
		c1.getPassagens().add((Passagens) Arrays.asList(i2));
		
		
		System.out.println("\n\nUsuario: " + c1.getUsuario().getNome());
		
		for (Passagem i : c1.getID_Passagem()) {
			System.out.println("Passagem: "+ i.getID_Passagem() 
					+" quantidade: "+ i.getIda() 
					+" valor: " + i.getValor());
		}
		
		System.out.println(" \nValor compra: " + c1.getValor());
	}

	public PrincipalCRUD() {
	}

}