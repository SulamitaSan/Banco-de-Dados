package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Agencia.Passagem;
import conexao.ConexaoMySQL;
import crud.PassagemCRUD;

public class PassagemDAO {

	private static final String PassagemDAO = null;

	/*
	 * CRUD
	 * c: CREATE
	 * r: READ
	 * u: UPDATE
	 * d: DELETE 
	 */

	public PassagemDAO(int id_passagem, String Volta,String Ida, double valor1) {
		return;
	}

	public PassagemDAO() {
		return;
	}

	public PassagemDAO(int id_passagem, String destino, double valor1) {
		return;
	}

	public PassagemDAO(int i, int j, CompraDAO c1) {
	}

	public static void save(PassagemCRUD l1) {
			
	String sql = "INSERT INTO Passagem(ID_Passagem, ID_Cliente, Valor, Ida, Volta)" + " VALUES (?, ?, ?, ?, ?)";
		
	Connection conn = null;
	PreparedStatement pstm = null;
		
	try {
		//Criar uma conexão com o banco de dados
		conn = ConexaoMySQL.createConnectionToMySQL();
		 
		pstm = (PreparedStatement) conn.prepareStatement(sql);
		
		pstm.setString(1, l1.getID_Passagem());
		pstm.setString(2, l1.getID_Cliente());
		pstm.setString(3, l1.getValor());
		pstm.setString(4, l1.getIda());
		pstm.setString(5, l1.getVolta());
		
		
		// Executa a sql para inserção dos dados
		pstm.execute();
		}catch (Exception e) {
				e.printStackTrace();
		} finally {
				// Fecha as conexões
				try {
				if (pstm != null) {
						pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
				} catch (Exception e) {
					e.printStackTrace();
			}
		}
	}

	public void removeById(int id) {

		String sql = "DELETE FROM passagem WHERE id = ?";

		Connection conn = null;
	
		PreparedStatement pstm = null;
		
		try {
			conn = ConexaoMySQL.createConnectionToMySQL(); // cria a conexao

			pstm = (PreparedStatement) conn.prepareStatement(sql); // passa comando sql para o objeto pstm
		
			pstm.setInt(1, id); // seta o id no comando sql
			
			pstm.execute(); // executa o comando sql que está no objeto pstm

		} catch (Exception e) {			
			e.printStackTrace();
		} finally {

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (conn != null) {
					conn.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}
		}
	}

	public static void update(PassagemDAO l2) {

		String sql = "UPDATE passagem SET ID_Passagem = ? ID_Cliente = ?, Valor = ?, Ida = ?, Volta = ?" + " WHERE id = ?";

		Connection conn = null;
		PreparedStatement pstm = null;
		try {
			// Cria uma conexão com o banco
			conn = ConexaoMySQL.createConnectionToMySQL();

			// Cria um PreparedStatment, classe usada para executar a query
			pstm = (PreparedStatement) conn.prepareStatement(sql);

			pstm.setInt(1, l2.getPassagemCRUD());
			pstm.setFloat(2, l2.getID_Cliente());
			pstm.setDouble(3, l2.getValor());
			pstm.setString(4, l2.getIda());
			pstm.setString(5, l2.getVolta());

			// Executa a sql para inserção dos dados
			pstm.execute();

			} catch (Exception e) {

				e.printStackTrace();
			} finally {

				// Fecha as conexões

				try {
					if (pstm != null) {

						pstm.close();
					}

					if (conn != null) {
						conn.close();
					}

				} catch (Exception e) {

					e.printStackTrace();
				}
			}
		}

		private int getPassagemCRUD() {
		return 0;
	}

		private String getVolta() {
		return null;
	}

		private String getIda() {
		return null;
	}

		private double getValor() {
		return 0;
	}

		private float getID_Cliente() {
		return 0;
	}

		@SuppressWarnings("null")
		public static int getPassagem() {

			String sql = "SELECT * FROM passagem";

			@SuppressWarnings("unused")
			Passagem passagem = new Passagem();

			// Classe que vai recuperar os dados do banco de dados
			ResultSet rset = null;

			Connection conn = null;
			PreparedStatement pstm = null;
			try {
				conn = ConexaoMySQL.createConnectionToMySQL();

				pstm = (PreparedStatement) conn.prepareStatement(sql);
				
				rset = pstm.executeQuery();

				// Enquanto existir dados no banco de dados, faça
				while (rset.next()) {
					
					PassagemDAO l2 = null;
					pstm.setInt(1,l2.getPassagemCRUD());
					pstm.setFloat(2, l2.getID_Cliente());
					pstm.setDouble(3, l2.getValor());
					pstm.setString(4, l2.getIda());
					pstm.setString(5, l2.getVolta());

					Passagem passagem1 = new Passagem();

					// Recupera a passagem do banco e atribui ele ao objeto
					passagem1.setID_Passagem(rset.getInt("Passagem"));

					// Recupera o id do banco e atribui ele ao objeto
					passagem1.setID_Cliente(rset.getString("Id"));

					// Recupera o valor do banco e atribui ele ao objeto
					passagem1.setValor(rset.getInt("Valor"));

					// Recupera a Ida do banco e atribui ela ao objeto
					passagem1.setIda(rset.getString("Ida"));
					
					// Recupera a Volta 
					passagem1.setVolta(rset.getInt("Volta"));

					// Adiciono o passagem recuperado, a lista de passagem
					passagem1.add(passagem1);
				}
			} catch (Exception e) {

				e.printStackTrace();
			} finally {

				try {

					if (rset != null) {

						rset.close();
					}

					if (pstm != null) {

						pstm.close();
					}

					if (conn != null) {
						conn.close();
					}

				} catch (Exception e) {

					e.printStackTrace();
				}
			}

			return getPassagem();
		
		}

		public static PassagemCRUD getPassagemById(int id_passagem) {
			return null;
		}

		public static void deleteById(int posicao) {
			
		}

		public static Passagem[] getPassagemDAO() {
			return null;
		}

		public static String getPassagemdao() {
			return PassagemDAO;
		}
	}

