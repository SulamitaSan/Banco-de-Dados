package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Agencia.Permissoes;
import Agencia.Usuario;
import conexao.ConexaoMySQL;

public class UsuarioDAO {
	
	/*
	 * CRUD
	 * c: CREATE
	 * r: READ
	 * u: UPDATE
	 * d: DELETE 
	 */

	public UsuarioDAO(String id_usuario, String nome, String idade, String endereco, String id_permissao,
			String compra) {
	}

	public UsuarioDAO() {
		return;
	}

	public UsuarioDAO(int i, String string, String string2, String string3, Permissoes p1) {
	}

	public void save(Usuario usuario) {
		
	String sql = "INSERT INTO Cliente(id_usuario, nome, idade, endereco, id_permissao, compra)" + " VALUES (?, ?, ?, ?, ?, ?)";
	
	Connection conn = null;
	PreparedStatement pstm = null;
	
	try {
		//Criar uma conexão com o banco de dados
		conn = ConexaoMySQL.createConnectionToMySQL();
		 
		pstm = (PreparedStatement) conn.prepareStatement(sql);
		
		pstm.setString(1, usuario.getId_usuario());
		pstm.setString(2, usuario.getNome());
		pstm.setString(3, usuario.getIdade());
		pstm.setString(4, usuario.getEndereco());
		pstm.setString(5, usuario.getId_permissao());
		pstm.setString(6, usuario.getCompra());
		
		// Executa a sql para inserção dos dados
		pstm.execute();
		}catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conexões

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (conn != null) {
					conn.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}
		}
	}

	public void removeById(int id) {

		String sql = "DELETE FROM usuario WHERE id = ?";

		Connection conn = null;
		PreparedStatement pstm = null;
		try {
			conn = ConexaoMySQL.createConnectionToMySQL(); // cria a conexao

			pstm = (PreparedStatement) conn.prepareStatement(sql); // passa comando sql para o objeto pstm

			pstm.setInt(1, id); // seta o id no comando sql

			pstm.execute(); // executa o comando sql que está no objeto pstm

		} catch (Exception e) {			
			e.printStackTrace();
		} finally {

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (conn != null) {
					conn.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}
		}
	}

	public void update(Usuario usuario) {

		String sql = "UPDATE usuario SET id_usuario = ?, nome = ? , idade = ?, endereco = ?, id_permissao = ?, compra = ?" + " WHERE id = ?";

		Connection conn = null;
		PreparedStatement pstm = null;
		try {
			// Cria uma conexão com o banco
			conn = ConexaoMySQL.createConnectionToMySQL();

			// Cria um PreparedStatment, classe usada para executar a query
			pstm = (PreparedStatement) conn.prepareStatement(sql);

			pstm.setString(1, usuario.getId_usuario());
			pstm.setString(2, usuario.getNome());
			pstm.setString(3, usuario.getIdade());
			pstm.setString(4, usuario.getEndereco());
			pstm.setString(5, usuario.getId_permissao());
			pstm.setString(6, usuario.getCompra());

			// Executa a sql para inserção dos dados
			pstm.execute();

		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conexões

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (conn != null) {
					conn.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}
		}
	}

	public List<Usuario> getUsuario() {

		String sql = "SELECT * FROM usuario";

		List<Usuario> usuario = new ArrayList<Usuario>();

		// Classe que vai recuperar os dados do banco de dados
		ResultSet rset = null;

		Connection conn = null;
		PreparedStatement pstm = null;
		try {
			conn = ConexaoMySQL.createConnectionToMySQL();

			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			rset = pstm.executeQuery();

			// Enquanto existir dados no banco de dados, faça
			while (rset.next()) {
				
				Usuario usuario1 = new Usuario(0, sql, sql, sql, null);

				// Recupera o id do banco e atribui ele ao objeto
				usuario1.setId_usuario(rset.getInt("id"));

				// Recupera o nome do banco e atribui ele ao objeto
				usuario1.setNome(rset.getString("nome"));

				// Recupera a idade do banco e atribui ele ao objeto
				usuario1.setIdade(rset.getInt("idade"));

				// Recupera o endereço do banco e atribui ela ao objeto
				usuario1.setEndereco(rset.getString("Endereço"));
				
				// Recupera a permissão 
				usuario1.setId_permissao(rset.getInt("Permissao"));
				
				//Recupera a compra do usuario
				usuario1.setCompra(rset.getInt("Compra"));

				// Adiciono o contato recuperado, a lista de contatos
				usuario1.add(usuario1);
			}
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			try {

				if (rset != null) {

					rset.close();
				}

				if (pstm != null) {

					pstm.close();
				}

				if (conn != null) {
					conn.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}
		}

		return usuario;
	
	
	}

	public char[] mostrar() {
		return null;
	}

	public static String getId_usuario() {

		return null;
	}

	public String getNome() {
	
		return null;
	}

	public static String getIdade() {
	
		return null;
	}

	public String getEndereco() {
	
		return null;
	}

	public String getId_permissao() {
	
		return null;
	}

	public String getCompra() {
		
		return null;
	}
}
