package Agencia;

import java.util.HashSet;
import java.util.Set;

public class Permissoes {
 
    private int id_permissao;
   
    private int tipo_permissao;
    
   
    private HashSet<Usuario> usuario;
    
  
    public Permissoes(int i, String string) {
		
	}

	public int getId_permissao() {
        return this.id_permissao;
    }
  
    public void setId_permissao(int id_permissao) {
        this.id_permissao = id_permissao;
    }
    
  
    public int getTipo_permissao() {
        return this.tipo_permissao;
    }
   
    public void setTipo_permissao(int tipo_permissao) {
        this.tipo_permissao = tipo_permissao;
    }
    
    
    public Set<Usuario> getUsuario() {
        if (this.usuario == null) {
            this.usuario = new HashSet<Usuario>();
        }
        return this.usuario;
    }
    

    public void setUsuario(HashSet<Usuario> usuario) {
        this.usuario = usuario;
    }

	public String getTipo() {
		return null;
	}
    
    
    
}
