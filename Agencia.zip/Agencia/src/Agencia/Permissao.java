package Agencia;

public class Permissao {

    private int ID_Permissao;
   
    private String tipo_Permissao;

   
    public int getID_Permissao() {
        return this.ID_Permissao;
    }
    
   
    public void setID_Permissao(int ID_Permissao) {
        this.ID_Permissao = ID_Permissao;
    }

    public  Object getAttribute() {
        return this.getAttribute();
    }
    
    public String getTipo_Permissao() {
        return this.tipo_Permissao;
    }
    

    public void setTipo_Permissao(String tipo_Permissao) {
        this.tipo_Permissao = tipo_Permissao;
    }


	public void add(Permissao permissao) {
		this.add(permissao);
	}

       
    
   
}
