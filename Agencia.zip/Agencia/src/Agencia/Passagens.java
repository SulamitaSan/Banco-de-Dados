package Agencia;

public class Passagens {
    
 
    private int id_passagem;
    
    private String destino;
    
    private String origem;
   
    private double id_compra;
 
    private int compra;
 
    public int getId_passagem() {
        return this.id_passagem;
    }
  
    public void setId_passagem(int id_passagem) {
        this.id_passagem = id_passagem;
    }
    
    public String getDestino() {
        return this.destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }    

    public String getOrigem() {
        return this.origem;
    }
   
    public void setOrigem(String i) {
        this.origem = i;
    }
    
   
    public double getId_compra() {
        return this.id_compra;
    }
  
    public void setId_compra(double id_compra) {
        this.id_compra = id_compra;
    }
    
 
    public int getCompra() {
        return this.compra;
    }
 
    public void setCompra(int i) {
        this.compra = i;
    }

	public void setFloat(int int1) {
		this.setFloat(int1);		
	}

	public void add(Passagens passagens) {
		this.add(passagens);	
	}
    
    
    
}
