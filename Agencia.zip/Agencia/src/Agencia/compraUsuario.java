package Agencia;

public class compraUsuario {

	    private int id_compra;
	  	
	    private int id_usuario;
	
	    private Usuario usuario;
	
	    private Compra compra;

	    public int getId_compra() {
	        return this.id_compra;
	    }

	    public void setId_compra(int id_compra) {
	        this.id_compra = id_compra;
	    }
	  
	    public int getId_usuario() {
	        return this.id_usuario;
	    }
	
	    public void setId_usuario(int id_usuario) {
	        this.id_usuario = id_usuario;
	    }
	
	    public Usuario getUsuario() {
	        return this.usuario;
	    }
	 
	    public void setUsuario(Usuario usuario) {
	        this.usuario = usuario;
	    }
	    
	
	    public Compra getCompra() {
	        return this.compra;
	    }
	
	    public void setCompra(Compra compra) {
	        this.compra = compra;
	    }
	   
	    
	}
