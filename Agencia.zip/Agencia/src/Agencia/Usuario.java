package Agencia;

public class Usuario {
  
    
    private String id_usuario;
    private String idade;
    private String nome;
    private String endereco;
    private String id_permissao;
    private String compra;
 
    
    public Usuario(int i, String string, String string2, String string3, Permissoes p2) {
    	return;
	}

	public Usuario(int int1, String string, String string2, String string3, String string4, int int2) {
		return;
	}

	public String getId_usuario() {
    	return this.id_usuario;
    }
  
    public void setId_usuario(String i) {
        this.id_usuario = i;
    }

	public Agencia.Permissoes permissoes; public String getIdade() {
        return this.idade;
    }
    
    public void setIdade(String idade) {
        this.idade = toString();
    }
    
    public String getNome() {
        return this.nome;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getEndereco() {
    	return this.endereco;
    }
    
    public void setEndereco(String endereco) {
    	this.endereco = endereco;
    }

    public  String getId_permissao() {
        return this.id_permissao;
        }

    public void setId_permissao(String id_permissao) {
        this.id_permissao = id_permissao;
    }

    public String getCompra() {
        return this.compra;
    }
    
    public void setCompra(String compra) {
        this.compra = compra;
    }
    
    public Permissoes getPermissoes() {
        return this.permissoes;
    }
     
    public void setPermissoes(Permissoes permissoes) {
        this.permissoes = permissoes;
    }

	public void add(Usuario usuario) {
		this.add(usuario);
	}

	public String mostrar() {
		return "Id: "+ this.id_usuario +" Nome: " +this.nome 
					+ " Email: " + this.idade 
					+ " Senha: " + this.endereco
					+ " Tipo permiss�o: " + this.permissoes.getTipo(); 
	}

	public void setId_usuario(int int1) {
		return;
	}

	public void setIdade(int int1) {
		return;
	}

	public void setId_permissao(int int1) {
		return;
	}

	public void setCompra(int int1) {
		return;
	}   
}
