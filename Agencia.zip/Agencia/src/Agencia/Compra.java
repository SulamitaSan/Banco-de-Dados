package Agencia;

import java.util.HashSet;
import java.util.Set;

public class Compra {
 
    private int id_compra;

    private double passagem;
    
    private double valor;
 
    private Set<Passagens> passagens;

    private HashSet<Compra> compra;

	@SuppressWarnings("unused")
	private int attribute;
	
  
	public Compra(int i, Usuario u3) {
		
	}

	public int getId_compra() {
        return this.id_compra;
    }
 
	public void setId_compra(int id_compra) {
        this.id_compra = id_compra;
    }
    
	public double getPassagem() {
        return this.passagem;
    }
     
	public void setPassagem(double string) {
        this.passagem = string;
    }
 
    protected  Object getAttribute() {
        return this.getAttribute();
    }

    protected  void setAttribute(int attribute) {
        this.attribute = attribute;
    }
 
    public double getValor() {
        return this.valor;
    }
    
   
    public void setValor(double valor) {
        this.valor = valor;
    }

    public Set<Compra> getCompra() {
        if (this.compra == null) {
            this.compra = new HashSet<Compra>();
        }
        return this.compra;
    }

    public void setCompra(HashSet<Compra> compra) {
        this.compra = compra;
    }
    
    public Set<Passagens> getPassagens() {
        if (this.passagens == null) {
            this.passagens = new HashSet<Passagens>();
        }
        return this.passagens;
    }
    
    @SuppressWarnings("unchecked")
	public void setPassagens(Passagens passagens) {
        this.passagens = (Set<Passagens>) passagens;
    }

	public void setPassagem(String string) {
		return;	
	}

	public void setPassagens(String string) {	
		return;
	}

	public void setCompra(int int1) {
		return;
	}

	public void add(Compra compra2) {
			return;
	}

	public Passagem[] getID_Passagem() {
		
		return null;
	}

	public Usuario getUsuario() {
		
		return null;
	}
    
    
    
}
