package Agencia;

public class Passagem {
 
    private int ID_Passagem;
    
    private float ID_Cliente;
 
    private double Valor;
 
    private String Ida;
   
    private String Volta;
  
    private Usuario cliente;

    public Passagem(int i, int j, Compra c1) {
		
	}

	public Passagem() {
		return;
	}

	public int getID_Passagem() {
        return this.ID_Passagem;
    }
  
    public void setID_Passagem(int ID_Passagem) {
        this.ID_Passagem = ID_Passagem;
    }
    
    public double getValor() {
        return this.Valor;
    }
 
    public void setValor(double Valor) {
        this.Valor = Valor;
    }
 
    public String getIda() {
        return this.Ida;
    }
    
    public void setIda(String i) {
        this.Ida = i;
    }
    
    public String getVolta() {
        return this.Volta;
    }

    public void setVolta(String i) {
        this.Volta = i;
    }
    
    public float getID_Cliente() {
        return this.ID_Cliente;
    }
 
    public void setID_Cliente(float string) {
        this.ID_Cliente = string;
    }

    public Usuario getCliente() {
        return this.cliente;
    }
   
    public void setCliente(Usuario cliente) {
        this.cliente = cliente;
    }

	public void add(Passagens passagens) {
		this.add(passagens);
	}

	public void setVolta(int int1) {
		this.setVolta(int1);
	}

	public void setID_Cliente(String string) {
		this.setID_Cliente(string);
	}

	public String getDestino() {
		return this.getDestino();
	}

	public void add(Passagem passagem1) {
		
	}

}
